<?php

namespace SaleAlerts;

class Config
{
    public static $priceDiffPercentageFromLowest = 5;
    public static $priceDiffPercentageFromLast = 5;
    public static $priceDiffPercentageFromAverage = 10;

    public static $printEmail = true;

    public static $apiKey = 'hero';

    public static $dbConnectionString = 'mysql:host=127.0.0.1;dbname=sale_alerts;charset=utf8';
    public static $dbUser = 'joeloliveira';
    public static $dbPassword = 'Z9qUAuqrxCqvGCE3';

    public static $mandrillApiKey = 'E8yFHfyIhP442rVl-ShPTw';
    public static $emailSaleAlertSubject = 'Sale Alert';
    public static $emailBuildReportSubject = 'Build Report';
    public static $emailSource = 'app@joeloliveira.me';
    public static $emailSourceName = 'Sale Alerts App';
    public static $emailDestination = 'joelfilipeoliveira@gmail.com';
    public static $emailDestinationName = 'Joel Oliveira';

    public static $providers = array('kuantokusta.pt' => 'KK');

    public static $allowedStores = array('alientech.pt', 'novoatalho.pt', 'globaldata.pt', 'pcdiga.pt', 'mhr.pt', 'aquario.pt', 'prinfor.pt', 'globaldata.pt', 'moddingworld.pt', 'mbit.pt');
}